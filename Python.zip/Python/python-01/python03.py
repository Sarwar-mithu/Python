#ASSIGNMENT OPERATORS
a = 10 
b = 20
m = 15

y = a + b
print(y)

m += 10
print(m)

m = 15
m -= 10
print(m)

m = 15
m *= 10
print(m)

m = 15
m /= 10
print(m)

m = 15
m **= 2
print(m)

m = 15
m //= 10
print(m)
print()

print("Bitwise Operator start from here : ")
#Bitwise AND => &
a = 10 
b = 15
c = a & b
print('a&b : ',c)

c = a | b
print('a|b : ',c)

c = a ^ b
print('a^b : ',c)

c = a<<2
print('Left shift : ',c)

c = a>>2
print('Right shift : ',c)

c = ~a
print('~a : ',c)
print()

print("Membership Operator start form here : ")
#Membership Operator(in,not in)

name = "Welcome to my world "
print('in word write a : ', "to" in name)

name = "My favourite color is Black"
print('in word write a : ', "is" in name)

name = "My name is mithu"
print('in word write a : ', "was" in name)

name = "sarwar mithu"
print('in word write a : ', "mith" in name)


print("not in   start from here : ")
ob = "Welcome to my world"
print('not in ,word write a : ', "to" not in ob)

ob = "Welcome to my world"
print('not in ,word write a : ', "tos" not in ob)
