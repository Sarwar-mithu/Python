#Built-in Datatype


#list
data = [10, 20, 8.56,"string float, complex"]  
print(data)
print(data[1]) #index number in check value

data[3] = "Replace index value" #replace for value
print(data)



#tuple 
print("Tuple start here : ")   
data1 = (88, 99, 7.345, "tuple")   #(kaj hocce list moto tobe ar kono modify/replace kora jabe na)
print(data1)




#rang keyword
rg = range(5)
print("0-5 projonoto print : ")
print(rg)


new_rg = range(10,20,2)
print("10-20 projonoto print 2 kore vabhodan takbe :")
print(new_rg)
print(new_rg[1])

#SET TYPE (index number hoy na)
data = {10,20,30,"sarwar","mithu", 4}  #unOrder collection
print(data)


d = {10,20,30,20,40,70,20,99} # ekai value print korbe na garbage kore dibe
print(d)



#MAPPING TYPE/DICT/DICTIONARY
data = {101:"Aayash", 102:"Medehi", 103:"Sajada"} # parent ar child clase
print(data)
print(data[103])