#DECLARING AND INITIALZING VARIABLE
#OPERATOR (,ARITHMETIC,RELATIONAL,LOGICAL,ASSIGNMENT,MEMBERSHIP,IDENTITY)


#ARITHMETIC OPERATOR
#ADDITION 
a = 10
b = 20
addition = a + b
print(addition)
print()


#SUBRACTION OPERATOR
a = 6
b = 2
subtraction = a - b
print(subtraction)
print()

#MULTIPLICATION OPERATOR
a = 3
b = 2
multiplication = a * b
print(multiplication)
print()

#DIVISION OPERATOR
a = 5
b = 3
division = a / b
print(division)
print()

#MODULOUS OPERATOR
a = 5
b = 2
modulous = a % b
print(modulous)
print()

#EXPONENT OPERATOR
a = 5
b = 2
exponent = a**2
print(exponent)
print()

#INTEGER DIVISION/FLOOR DIVISION
a = 5
b = 2
floor = a//b
print(floor)

A =-7
B = 3
CILING = A//B
print(CILING)
print()


#RELATIONAL OPERATOR, ,
print("Relation Operatir Start here : ")
num1 = 5
num2 = 2
cal = num1<num2
print(cal)

cal = num1>num2
print(cal)

cal = num1<=num2
print(cal)

cal = num1>=num2
print(cal)

cal = num1==num2
print(cal)

cal = num1 != num2
print(cal)
print()


#LOGICAL OPERATOR
print("logical Operator start here : ")
#and logical operator
a = 5
b = 2
c = 3

logi = (a>b and a>c)
print(logi)

logi = (a>b and a<c)
print(logi)

logi = (a<b and a<c)
print(logi)

A = 5
B = 2
C = 100
D = 200

logi = (A>B and C)  #expression  tai dekabe
print(logi)

logi = (A<B and C)  #Flase  tai dekabe
print(logi)

logi = (A>B and C and D)  #Right expression  tai dekabe
print(logi)


print("or logical operator start here : ")
a = 5
b = 2
c = 3

logiOr = (a>b or c>b)
print(logiOr)

logiOr = (a>b or c<b)
print(logiOr)

logiOr = (a<b or c>b)
print(logiOr)

logiOr = (a<b or c<b)
print(logiOr)

logiOr = (a>b or c)
print(logiOr)

logiOr = (a<b or c)
print(logiOr)


print("logical Not start from here : ")

a = 10
b = 6
logicNot = (not (a>b))
print(logicNot)

logicNot = (not (a<b))
print(logicNot)