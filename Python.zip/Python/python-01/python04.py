#Identity Operators (is, is not)

a = 10 
b = 10
c = 20

compair = a is b
print('Same memory address is : ', compair)

compair = a is c
print('Same memory address is : ', compair)

print("is not, start from here : ")

compair = a is not b
print('Same memory address is : ', compair)

compair = a is not c
print('Same memory address is : ', compair)
print()


print("Operator Precedence and Associativity")
#Operator Precedence and Associativity

print("Type conversion start form  here : ")
#Explicit type conversion
#Type conversion[int(n),float(n),complex(n),str(n),list(n),tuple(n),bin(n),oct(n),hex(n)]

a = 5 
b = 2
value = a/b
print('Float to Integer conversion : ', int(value))

a = 10
b = 5
value = a + b
print('Integer to float conversion : ', float(value))

a = 4
b = '10'
value = 4 + int(b)
print('Integer to string conversion : ', value)

a = 49
print('Integer to Complex conversion : ', complex(a))


name = "Sarwar mithu"
print('String to tuple conversion : ', tuple(name))

name = "Sajada Akther"
print('String to List conversion : ', list(name))

other = ("Sajada", "Taher","Mehedi","Aayash","Vabhi")
print('tuple to list conversion : ', list(other))
print()

a = 10
print('decimal to Binary : ', bin(a))

a = 874
print('decimal to Octal : ', oct(a))

a = 874
print('decimal to Hexadecimal : ', hex(a))
