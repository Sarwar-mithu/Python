#List Of Tuples
#Tuple of List


a = [10,20,7,(40,50)]
print('Orginal List A :',a)
print(id(a))
print(type(a))
print()

#Appending a new Tuple
a.append((60,70))
print('After appending a tuple:',a)
print()

#Accessing List of tuple using for loop
n = len(a)
for i in range(n):
    if type(a[i]) is tuple:
        if len(a[i])>1:
            m = len(a[i])
            for j in range(m):
                print(i,'->',j,':',a[i][j])
    
    else:
        print(i,a[i])
print()


#Tuple of List
x = (9,8,7,[5,6])
print('Orginal Tuple :',x)
print(id(x))
print(type(x))
print()

#Modifying List
x[3][0]= 40
print('After Modifying Tuple:',x)
print()

#accessing tuple of lists using for loop
n = len(x)

for i in range(n):
    if type(x[i]) is list:
        if len(x[i])>1:
            y = len(x[i])
            for j in range(y):
                print(i,j,'=',x[i][j])

    else:
        print(i,x[i])
print()


#another example
a = ([10,20],[30,40,50])
print('Orginal Tuple:',a)
print()

a[1][2] = 100              #modifying list
print('After Modify : ',a)

n = len(a)      #accessing tuple of list using for loop
for i in range(n):
    for j in range(len(a[i])):
        print(i,j,a[i][j])
    print()