#Higher Order Function
#filter()->filter(function_name, iterable)
#map()->map(function_name, iterable)
#reduce()-> reduce(function_name, sequence) = from functools import reduce
#Generator function yield statement and next function -> next()

a = [10,20,50,60,80,77,3,5,33,65]

def high_marks(n):
    if n>=60:
        return True


result = list(filter(high_marks, a))
print(result)
print(type(result))
for i in result:
    print(i)
print()

#filter with lambda Function
b = [12,15,17,8,25,9,22,3,24]
x = list(filter(lambda n: (n>=15), b))

print(x)
print(type(x))

for i in x:
    print(i)
print()


#map() Function
a = [10,20,30,40,50]

def inc(n):
    return n+2

result = list(map(inc, a))
print(result)
print(type(result))
for i in result:
    print(i)
print()



#map with lambda function
a = [11,22,33,40,50]
result = list(map(lambda n : n+3, a))
print(result)
print(type(result))
for i in result:
    print(i)
print()


#another example
a = [11,22,33,40,50]
b = [1,2,3,4,5]
result = list(map(lambda n,m : n+m, a,b))
print(result)
print(type(result))
for i in result:
    print(i)
print()




#reduce() Function
from functools import*
a = [5,10,30,25,15]

result = reduce(lambda n,m: n+m, a)
print('addition', result)
print(type(result))
print()



#Generator yield and next()

def disp(a,b):
    yield a
    yield b

x,y = disp(10,20)
print(x)
print(y)
print()

#next()
def disp(a,b):
    yield a
    yield b

result = disp(5,7)
print(result)
print(type(result))

print(next(result))
print(next(result))


lst = list(result)
print(lst)
print(type(lst))
print()


#another example
def show(m,n):
    while m<=n:
        yield m
        m+=1

result = show(1,5)
print(result)
print(type(result))

print(next(result))
print(next(result))


for i in result:
    print(i)
