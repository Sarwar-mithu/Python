#Tuple 
#Access tuple using for loop and while loop 
#slicing on Tuple-> tuple_name[sart:stop:stepsize]
#tuple Concatenation-> a, b, result = a+b
#Modifying Element-> Immutable
#Deleting Tuple-> same tricky modify element
#Repetition of Tuple-> *
#Aliasing Tuple-> nick name deoa
#copying Tuple->
#getting input from user tuple

a = (1,6,7,'sarwar')
print(a)
print(type(a))

n = len(a)
for i in range(n):
    print(i,':',a[i])
print()


#Slicing on tuple , [1:5],[0:],[:5],[-4:],[-5:-3],[0:5:2]
x = (9,8,7,'mithu',5,6)
print('Orginal tuple')
n = len(x)
for i in range(n):
    print(i,':',x[i])
print()


print('from 1st position to 4th position')
a = x[1:5]
for i in a:
    print(i)
print()


#Modify tuple is not possible, but tricky way solve this modify

a = (10,20,-50,21.4,'mithu')
print(a)

c = (101,102)
s1 = a[0:2]
s2 = a[2:]

tup1 = s1+c+s2
print(tup1)
print()

#Repetition
a = (1,2,3)
print(a)
result = a*3
print(result)
print()


#Aliasing Tuple
a = (1,2,1)
b = a
print('A',a)
print('B',b)
print()
#Delete del a

#user input
a = []
n = int(input('How many Elements : '))

for i in range(n):
    a.append(int(input('Enter Elements : ')))
print(type(a))

a = tuple(a)    #Convert list to tuple
print(type(a))

print('Tuples :',a)
for el in a:
    print(el)
print()
