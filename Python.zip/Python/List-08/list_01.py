#list 
#method -> append(),
#user input list


a = [10,20,40.56,-5,'sarwar mtihu']
print(a)

le = len(a)
for i in range(le):
    print(i,'= ',a[i])
print()

a[2] = 3.1416
n = len(a)
print(a)
for j in range(n):
    print(j,'modify ->',a[j])

print()


#append()
a.append('Python')
print('After appending method')
for i in a:
    print(i)
print()


#User input list
x = []
n = int(input('Enter number of Elements: '))

for i in range(n):
    x.append(int(input('Data Entry : ')))

print('list')
for j in x:
    print(j)
print()