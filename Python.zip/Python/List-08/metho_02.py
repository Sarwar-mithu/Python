#Method -> 
#insert() -> list_name.insert(position_number,new_elemet)
#pop(specified position)->this method is used remove last element from the existion list
#remove()->list_name.remove(element)=first occurrence of given
#index()->list_name.index(element)
#reverse()->list_name.reverse()
#extend()->list_name.extend(lst)=duiti list jog kora
#count()->list_name.count(specified_element)
#sort()->list_name.sort()
#clear()->list_name.clear()=delete all the elements from the list
#list concatenation -> +operator is used to do concatenation 
#Repetition of list-> *Operator is used to repeat the elements
#aliasing list
#copy() list
#cloning -> b = a[:]



a = [10, 20,-34,4.56,'Mithu']
print(a)
print()

a.insert(2,'Python')
for i in a:
    print(i)
print() 


#Repetition of list
a = [1,2,3]
print(a)
result  = a*3
print(result)
print()


#Alising List , same array hobe 
b = a
print('a =',a, id(a))
print('b =',b, id(b))
print()

#copy list, Modification in a will not affect b 
a = [1,2,3,4,8]
b = a.copy()
print('A: ',a)
print('B: ',b)
print()

print('Modifying A')
a[1] = 56
print('A: ',a)
print('B: ',b)
print()


print('Modifying B') 
b[3] = 77
print('A: ',a)
print('B: ',b)
print()