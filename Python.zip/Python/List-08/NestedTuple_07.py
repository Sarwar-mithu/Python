#Nested Tuple
#Slicing Nested tuple
#Passing Tuple to FUnction
#Retuning tuple


a = ((10,20,30),(40,50,60))
print(a)

for i in range(len(a)):
    for j in range(len(a[i])):
        print(i,j, a[i][j])
    print()

#another example
x = (11,22,33,(50,60))

n = len(x)

for i in range(n):                #while loop same
    if type(x[i]) is tuple:
        if len(x[i])>1:
            m = len(x[i])
            for j in range(m):
                print(i,j,':',x[i][j])
    
    else:
        print(i,x[i])
print()



#Passing Tuple to Function
def show(t):
    print(t)
    print(type(t))
    for i in t:
        print(i)

tup = (11,22,33,'mithu')
show(tup)
print()


#Returning Tuple
def show(t):
    print(t)
    print(type(t))
    for i in t:
        print(i)
    return t


tup = (1,2,3,'sarwar')
new_tup = show(tup)
print(new_tup)
print(type(new_tup))
print()