#Nested List
#Accessing Nested List
#Modifying Nested List
#for loop and while loop
#passing list to Function
#passing and Returning list
#list() Function-> list(range(start,stop,stepsize))


a = [10,20,30,[50,40]]      # b =[50,40], a=[10,20,30,b]
print(a)

n = len(a)
for i in range(n):
    print(i,':',a[i])
print()

print('Modifying Nested List')
print(a)
a[1]=55
a[3][1]=77
n = len(a)
for i in range(n):
    print(i,'modify->',a[i])
print()

#Another example

x =[ [11,22,33],
     [44,55,66] ]

print(x)
n = len(x)
for j in range(n):
        print(j,':',x[j])
print()

#with index
for r in range(n):
    for c in range(len(x[r])):
        print(r,c,'->',x[r][c])
    print()

print()



#complicated for loop with if else statement and index

a = [10,20,30,[40,50]]

n = len(a)
for i in range(n):
    if type(a[i]) is list:
        if len(a[i])>1:
            m = len(a[i])
            for j in range(m):
                print(i,j,'=',a[i][j])
    
    else:
        print(i,':',a[i])
print()


#while loop
print('while loop start')
i = 0
while i<n:
    if type(a[i]) is list:
        if len(a[i])>1:
            j = 0
            m = len(a[i])
            while j<m:
                print(i,j,a[i][j])
                j+=1
            i+=1
    
    else:
        print(i,a[i])
        i+=1
print()   



#passing list to function

def show(l):
    print(l)
    print(type(l))
    for i in l:
        print(i)
lst=[10,20,3,'sarwar']
show(lst)
print()



#passing and Returning list
def show(l):
    print(l)
    print(type(l))
    for i in l:
        print(i)
    return l

lst = [3,2.7,'mithu']
new_list = show(lst)
print(new_list)
print(type(new_list))
print()





#list() Function
a = list()
print(a)
print(type(a))

a = list(range(0, 5))
print(a)


