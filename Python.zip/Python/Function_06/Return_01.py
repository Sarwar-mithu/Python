#return(variable or expression)
#Nested Function
#Pass a Function as parameter
#Function return another Function

def add(y):
    x = 10
    c = x + y
    d = y - x
    return c, d

sum, sub = add(60)
print('Addition : ',sum)
print('subtraction : ',sub)
print()


#Nested Function
def disp():
    def show():
        print("Show Function")
    print("disp Function")
    show()

disp()
print()

#
def disp(st):
    def show():
        return "Show Function"
    result = show() + st + " Disp Function"
    return result


a = disp(" Concatenation")
print(a)
print()


#pass a function as parameter
def pas(sh):
    print("1st passing & " + sh())       #sh() = para()

def para():
    return "2d Parameter"

pas(para)
print()



#A Function return another Function
def disp():
    def show():
        return " Show Function "
    print("Disp FUnction")
    return show()

r_sh = disp()
print(r_sh)