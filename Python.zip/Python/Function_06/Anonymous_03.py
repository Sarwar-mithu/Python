#Anonymous Function or Lambdas
#Syntex :-> lambda argument_list : expression
#Nested lambda Function
#passing lambda function to another Function
#Returning lambda function
#immediately invoked function expressions 


sum = lambda x: print(x+1)
sum(5)
print()

add_sub= lambda x, y : (x + y, x -y)
a , s = add_sub(5,2)
print(a)
print(s)
print()


#Nested lambda function
add = lambda x=10 : (lambda y : x + y)

a = add()
print(a(20))
print()



#passing lambda function to another function
def show(a):
    print(a(8))

show(lambda x : x)
print()

#reaturning lambda function
def add():
    y =20
    return (lambda x : x + y)

a = add()
print(a(10))
print()


#immediately invoked function expressions
(lambda x , y : print( x + y))(4,2)
print()