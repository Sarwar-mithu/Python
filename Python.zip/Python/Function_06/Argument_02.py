#Actual and Formal Argument
#type of actual arguments -> (Positional,keyword,default,variable length, keyword variable length)

def add(x,y):  #Formal Arguments
    c = x + y
    print(c)

add(10,20)    #Actual Arguments
print()


#type of actual arguments
#Position arguments  add(10,20,30,40)

#keyword arguments 
def show(name,age):
    print(name,age)

show(age=24, name="mithu")
print()

#default arguments
def show(name, id=163410020):
    print(f"Name : {name}  Id : {id}")

show(name="sarwar")
print()

#variable length arguments

def add(*num):              #single *
    for i in num:
        print(i)

add("User many variable : ",10,20,30,40) 
print()


#keyword variable length arguments
def add(**num):          #double **
    z = num['a'] + num['b'] + num['c']
    print("Addition : ",z)

add(a=4, b=7, c=8)
print()
