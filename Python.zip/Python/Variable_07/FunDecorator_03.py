#Function Decorator


def call(num):
    def inner():
        print('IF : Before enhancing function')
        num()
        print('IF : After Enhancing FUnction')
    return inner


@call
def num():
    print('We will use this function')
    print('and will enhance this in decorator')


num()
print()


#another example
def decor(num):
    def inner():
        a = num()
        add = a + 5
        return add
    return inner

@decor
def num():
    return 10


print(num())
print()



#another example

def decor1(num):
    def inner():
        a = num()
        multi = a * 5
        return multi
    return inner

def decor(num):
    def inner():
        b = num()
        add = b + 5
        return add
    return inner

@decor
@decor1
def num():
    return 10

#num = decor(decor1(num))
print(num())

