#passing array to function
#passing and Returning array


from array import*

def show(ar):
    print(ar)
    print(type(ar))

    for i in ar:
        print(i)

a = array('i', [11,12,14,15,89])
show(a)
print()


#passing and returning array

def show():
    a = array('i', [33,56,78,89,45])
    return a


y = show()
print('Retuning array: ',y)
print(type(y))
for i in y:
    print(i)


#Passing and Returning Numpy array
from numpy import*

def show(ar):
    print('passed array ar: ',ar)
    print(type(ar))

    for i in ar:
        print(i)
    return ar
print()

a = array(['Aayash','Mehedi','Mishu','family'])
y = show(a)
print('Returning array Y :',y)
print(type(a))
for i in y:
    print(i)
print()




