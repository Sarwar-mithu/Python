#Local variable
#Golabal variables
#Global keyword
#Global() Function
#Recursion

a = 50       #golabal variable
def show():
    x = 10   #local variable
    print('local varibale : ',x)
    print('Golabal variable',a)

show()
print("Gloabal vairable",a)
print()


#Global keyword
i = 0

def show():
    global i    #global keyword
    i = i + 1
    print("keyword I : ",i)

show()
print('I ',i)
print()

#global() Function
a = 50

def show():
    a = 10
    print('Local variable A: ',a)
    x = globals()['a']
    print('Global variable: ',x)
    x = 40
    print('X : ',x)

show()
print()



#Recursion
i = 0
def myfun():
    global i
    i = i+1
    print('my Function : ',i)
    myfun()

myfun()