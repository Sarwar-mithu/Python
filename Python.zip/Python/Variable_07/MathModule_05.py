#numpy Built in Math FUnctions 
#Math Module

from numpy import*
a = array([25,81,49,64])
b = array([[4,9,16,25,],[36,16,4,49]])
print()
#sum()
print('a:',sum(a))
print('b:',sum(b))
print()

#prod()
print('a :',prod(a))    #maltipai
print('b :',prod(b))
print()

#sqrt()
print('a :', sqrt(a))
print('b :', sqrt(b))
print()



#Math Module
#floor(), ceil(), fabs(), factorial(n), sqrt(), pow(), sin(n), cos(n), tan(), gcd(n,m)

from math import*

print(floor(4.5))
print(ceil(6.5))
print(sqrt(49))
print(factorial(5))
print(pow(5,2))