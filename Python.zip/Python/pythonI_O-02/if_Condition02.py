num1 = input("Enter your first Number :")
num2 = input("Enter your second Number:")

if(num1>num2):
    print('num1 greater than num2 : ',num1)
print("Rast of the code")   
print()

#Nested if statement
a = int(input("1st number :"))
b = int(input("2nd number :"))

if(a>b):
    print("1st condition true: ",a)
    if(a<b):
        print("2nd condition true: ",b)

print("You ar losser")

print()

#if statement with logical Operator(or,not,etc)

if(5>2) and (6>1):
    print('If statment with logical Operator')
    if(8>2) and (6>4):
        print("Anothor condition is true")

if(4>2) and (3<1):
    print('problem for condition')
print('rest of the code')
print()

#If else Statement
if(num1>num2):
    print('num1 greater than num2=',num1)
else:
    print('A less than B =',num2)
print('if else statement end')
print()

#Nested if else Statement
a = 5
b = 2
c = 6
d = 3
if(a>b):
    print("a is greater than b :",a)
    if(8>6):
        print('8 Greater than 6 ')
    else:
        print('Oops ! better luck next time')
else:
    print('Another statement')
print("1st if else statement end")
print()

#if elif else statement
x = int(input("Enter your input :"))
y = int(input("Enter your input :"))

if(x > y):
    print("a is greater than b")

elif(x == y):
    print("a and b are equal")
elif(x < y):
    print('a is less than b')
else:
    print("Please enter your digit")

