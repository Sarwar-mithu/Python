#Break Statement/ continue statement,  pass statement

for i in range(10):
    if(i == 5):
        break
    print("value : ",i)
print("End for break statement")
print() 

#continue statement

for j in range(20):
    if(j == 2):
        continue
    if(j == 5):
        continue
    print("Skip this 2 : ",j)
print("End for continue statement")
print()

#Pass statement
if(5>2):
    pass
else:
    print("Pass ! plz next Question")
print("End for Pass statement")
print()