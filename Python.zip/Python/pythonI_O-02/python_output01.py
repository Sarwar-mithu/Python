#Output Statements
#Syntex :- print(objects, sep='character', end='character', file=sys.stdout, flush=Flase)
print("Welcome to Output statment")
print()
print('like',"Share", "subscirbe")
print()

data = [12, 23, 23.4,"Sarwar mithu"]
print(data)
print()

print("Taher","Sajada","Mehedi","Vabhi",sep='->')
print("Abbu","Maa","Vaiya", "vabhi", sep='@=>')
print()

print("Welcome","My","World", end='\t\t')
print("Sarwar mithu")
print()

x = 10
y = 20
print('Separate : ',x,y, sep=' $')
print()

name = "Sarwar"
roll = 163410020
print("My name is : ",name," & ","University Id : ",roll)
print()


print("User input start from here : ")
print()

name = input("Enter your name : ")
print("Name : ",name)

mobile = int(input("Enter Your Mobile No : "))
print("Mobile No :",mobile)
print

print("Escape Sequence")
#Escape Sequence(bell-> \a, backspace-> \b, formfeed-> \f, newline-> \n, carriage return-> \r,H_tab-> \t,V_tab-> \v)
print("Welcome to \t my world")
print()
print("My \"name\" is Mithu")

