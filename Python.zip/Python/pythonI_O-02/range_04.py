#range() function
#range(start,stop,stepsize)

a = range(1, 10, 2)
print("RANGE : ",a[0],a[1],a[2],a[3],a[4])
print()


#for loop

ob = "Sarwar mithu"
for i in ob:
    print(i)
print("for loop end")
print()

#for loop with range
w = range(1, 10, 2)
for j in w:
    print("Loop with range : ",j)
print()

#for loop with range and index number initializ

name = "Aayash cacchu","mithu"
n = len(name)
for i in range(n):
    print(i," = ",name[i])
print("End")
print()

#Another Example
t = range(1,10,2)
n = len(t)
for i in range(n):
    print(i," : ",t[i])
print("End for range")
print()


#Nested for loop with else
for i in range(3):
    print("Outer Loop : ",i)
    print()
    for j in range(4):
        print("Inner Loop : ",j)
else:
    print("perfect Loop in python ")

