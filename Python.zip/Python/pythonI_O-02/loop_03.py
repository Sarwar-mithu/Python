#Loop Control Statement
#while loop

a = 1
while(a <= 10):
    print("A = ",a)
    a+=1
print("While Loop End ")
print()

#While Loop with else
a = 1
while(a <= 5):
    print("a : ",a)
    a+=1
else:
    print("If while condition false")
print("While loop with else End")
print()

#Infinite while loop
i =0
while(True):
    i+=1
    print("I : ",i)
    if(i == 3):
        break
print("Infinite while loop end")
print()

#Nested while loop

i = 1
while(i<=3):
    print("Outer Loop ",i)
    i+=1
    j = 1
    while(j<=5):
        print("Inner Loop ",j)
        j+=1
print("Nested while loop End")
print()

i = 2
while(i<=4):
    i+=1
    print()
    j = 1
    while(j<=10):
        print(i," * ",j,"=",i*j)
        j+=1
print("end")




