#String Formatting -> (C-style, format() method, f-string/literal)
print('C-style start ')
print("%d" %432)
print("%8d" %432)
print("%08d" %432)

print("%f" %432.124567)
print("%.2f" %432.124567)
print("%9.3f" %432.124567)
print()

print("format() start from here ")
#RF = {index/key:[fill][align][sign][#][0][width][,][.precision]type}
print("*******Integer******")
print()
print("{}".format(10.567))  #float
print("index={1} index={0}".format(10,20))
print("{num1}".format(num1=10))
print("{num1}  {num2}".format(num1=30,num2=40))
print("{}".format("Sarwar mithu"))   #string
print()


print("int= {1} Float= {2} String= {0}".format("Sarwar mithu", 10, 3.1416))
print()

print("******Type*****")
print("index:type = {0:d}    {1:f}".format(90,12.321))
print()


print("*****Format Specification******")
#  :[fill][align][sign][#][0][width][,][.precision]type
print("{num:5d}".format(num=15))
print("{num:05d}".format(num=15))
print("{num:+5d}".format(num=15))    
print("{num:<5d}".format(num=15))    # <left side
print("{num:*<5d}".format(num=15))   # *fill
print("{num:>5d}".format(num=15))    # >Right side
print("{num:^5d}".format(num=15))    # ^Middle side
print("{num:*^5d}".format(num=15))   # fill,align,sign,width,type
print()
print("{num:8.2f}".format(num=3.1415786251)) # .precision
print()


print("{name:*^30}".format(name = "Special case"))
#[,] thousand for coma
print("{:,}".format(1234567890000))
print("{:_}".format(1234567890000))
print()

a = 50
b = 3
print("{:.2}".format(a/b))  #with Exponent
print("{:.2%}".format(a/b))  #without Exponent
print()


value = (66,88)   #tuple 
print("{0[0]} {0[1]}".format(value))
print()

data = {'Sarwar': 163410020, 'Afjal': 497192}
print("{0[Sarwar]:d}  {0[Afjal]:d}".format(data))

print("{Sarwar}  {Afjal}".format(**data))   #format parameter



