# f-string
#Syntex :- f"{index/key/name:[fill][align][sign][#][0][width][,][.precision]type}
a = 10.56
b = 20.435
print(f"{a}  {b}")

name1 = "sarwar"
name2 = "mithu"
print(f"{name1} {name2}")
print(f"Hello my name is: {name1} {name2} value: {a}")
print()

#  :[fill][align][sign][#][0][width][,][.precision]type
num = 15
print(f"{num:*^7d}")

a = 3.141578794322524
print(f"{a:*^10.4f}")

name = "sarwar"
print(f"{name:$^10s}")
print()


print("**********Special case********")
price = 1234567890
print(f"{price:,}")
print(f"{price:_}")

a = 50
b = 3
print(f"{a/b:.2%}")

value = (10, 50)
print(f"{value[0]} {value[1]}")


data = {'Sarwar': 163410020, 'Afjal': 497192}
print(f"{data['Sarwar']:d}  {data['Afjal']:d}")


name = "Sarwar mithu"
print(f"{name.upper()}")
print(f"{{10}}")
print()

#Date and time
from datetime import datetime
today = datetime(2021, 1,10)
print(f"{today:%d/ %b /%y}")

