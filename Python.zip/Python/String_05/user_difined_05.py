#user difined Function
#syntex:- def FUnction_name():        # local variable,block of statement,return(vari or exp)


def display():    #defining a Function
    name = "Sarwar mithu"
    print('Hello ',name)

display()          #calling a Function
display()
print('Ends for basic function structure')
print()


#Function with argument and parameter
def add(y):
    x = 20
    c = x + y
    print(c)

add(10)
print()

def add(y):
    x = 10.3456
    print(x + y)
    print(f"Formatted Output  {x+y:5.2f}")

add(20)