#single quotes, double quotes, tripall quotes, using escape, raw string
#Repetition Operator ("$" * 5), Muteable(list,set,dictionary) and immutable(variable name)
#Concatenation Operator,  Comparing String,

str1 = 'sarwar mithu'
print('single quotes: ',str1)
print()


str1 = "sarwar mithu"
print('Double quotes: ',str1)
print()

str1 = '''Hello Guys
         How are you ?
         whatw's up'''
print('Tripall single quotes: ',str1)
print()

str1 = """Hello Guys
Multipale line.
whatw's up"""
print('Tripall double quotes: ',str1)
print()

str1 = 'Hello "Sarwar mithu" single Quotes into double quotes'
print(str1)
print()

str1 = "Hello 'Sarwar mithu' Double Quotes into Single Quotes"
print(str1)
print()

str1 = r"Hello \n How are you. Escape Sequence?"
print(str1)
print()
le = len(str1)
print('Length : ',le)
print()


#Mutable and immutable Object
print('Mutable and immutable Object start ')



