#String Functions
#upper(),lower(),swapcase(),title()
#isupper(),islower(),istitle()
#isdigit(),isalpha(),isalnum(). isspace()
#lstrip(),rstrip(),strip()
#replace(),split(),join()
#startswith(),endswith()

name = "hello ! sarwar mithu"
print(name.upper())
print(name.lower())
print(name.swapcase())
print(name.title())
print()


nam = "i am Bangladeshi"
print(nam.isupper())
print(nam.islower())
print(nam.istitle())
print()


num = "234Enab7849j"
print(num)
print(num.isdigit())
print()

print(num)
print(num.isalpha())
print()

print(num)
print(num.isalnum())
print()

name = "sarwar mithu"
print(name)
print(name.isspace())
print()

name = "  sarwar mithu"
print(name)
print(name.lstrip())
print()




name = "sarwar mithu   "
print(name)
print(name.rstrip())
print()

name = "   sarwar mithu   "
print(name)
print(name.strip())
print()


#Syntex:- string.replace(old,new)
name = "GeekyShow"
old = "Geeky"
new = "New"
str1 = name.replace(old,new)
print(name)
print(str1)
print()


name = "How-are-you"
str1 = name.split('-')
print(name)
print(str1)
print()

name = ('Hello', 'How', 'are', 'You')
str1 = '_'.join(name)
print(name)
print(str1)
print()


#startswith(),endswith()
name = "Hi How are You"
print(name)
print(name.startswith('Hi'))
print(name.startswith('Hello'))
print()

#endswith()
print(name)
print(name.endswith('You'))
print(name.endswith('tnx')) 

