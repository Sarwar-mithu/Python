#array() Function
print("Start arraY() ")
from numpy import*
stu_roll = array([101,102,103])

n = len(stu_roll)
for i in range(n):
    print(i," = ",stu_roll[i]) 

print()
#while loop
from numpy import*
stu_roll = array([110,120,130])

n = len(stu_roll)
i = 0
while (i < n):
    print(i," : ",stu_roll[i])
    i+=1
print()

#linspace() Function
#array_name = linspace(start,stop,num = 50,endpoint=true)
print("Accessing one-D array elements")

from numpy import*
a = linspace(1, 8, 5, endpoint=False) 
print(a)

n = len(a)
for i in range(n):
    print(i," = ", a[i])
print()

