#2-D array/ multi-Dimensional Array
#Function -> array(),zeros(),ones(),reshape()
#array(object,dtype=None, copy=True, order='K', subok=False, ndmin=0)


from numpy import*

a = array([ [10,20,30,40],
            [99,88,77,66] ])

for r in a:
    for c in r:
        print(c)
    print()


#With index
print("with index ") 
le = len(a)

for r in range(le):
    for c in range(len(a[r])):
        print(a[r][c])
    print()



#while loop 
print("While loop ")
from numpy import*
x = array( [ [1,2,3,4],
             [9,8,7,6] ] )
n = len(x)

i = 0
while(i < n):
    j = 0
    while(j < len(x[i])):
        print('index',i,j,'= ',x[i][j])
        j+=1
    i+=1
    print()