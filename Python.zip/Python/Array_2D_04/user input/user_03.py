# zeros() Function   -> ones() Function equal
#zeros(shape, dtype=float)

from numpy import*
a = zeros((3,2),dtype=int)
print(a)

for r in a:
    for c in r:
        print(c)
    print()

#with index
print("with index ")
le = len(a)

for r in range(le):
    for c in range(len(a[r])):
        print(a[r][c])
    print()

#while loop
print("while loop")
n = len(a)
i = 0
while(i < n):
    j = 0
    while(j < len(a[i])):
        print(a[i][j])
        j+=1
    i+=1
    print()

#reshape() Function
#convert 1D array to 2D

a = array([1,2,3,4,5,6])
b = reshape(a,(2,3))
print(a)
print('After convert: ',b)
print()


#convert 1D array to 3D
from numpy import*
c = array([12,11,10,9,8,7,6,5,4,3,2,1])
x = reshape(c, (2, 3, 2))
print(c)
print('convert',x)
print()

#convert 2D to 1D array
n = array([[11,22,33], [55,66,77]])
g = reshape(n, (6))
print(g)