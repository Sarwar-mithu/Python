#user input for loop 2D

from numpy import*
m = int(input('Enter number of Rows : '))
n = int(input('Enter number of Columns : '))

a = zeros((m, n),dtype=int)
le = len(a)
print(a)

for r in range(le):
    for c in range(len(a[r])):
         x = int(input('Enter elements: '))
         a[r][c] = x


for i in range(len(a)):
    for j in range(len(a[i])):
        print(a[i][j])
    print() # 2D array
print(a)
print()


#while loop
print("while loop from start ")

i = 0
while(i < le):
    j = 0
    while( j < len(a[i])):
        q = int(input("Enter Elements : "))
        a[i][j] = q
        j+=1
    i+=1


i = 0
while(i < len(a)):
    j = 0
    while(j < len(a[i])):
        print('index',i,j,'= ',a[i][j])
        j+=1
    i+=1
    print()
print(a)
print()


print("slicing on 2D array ")
n = array( [[10,20,30],
            [40,50,60],
            [70,80,90]])
print('Orginal array')
print(n)

print('row ')
w = n[0, :]
print(w)
print('columns')
e = n[: ,1]
print(e)
e = n[0:1, 0:1]
print(e)
print()
q = n[0:2, 1:3]
print(q)
print()


#array_name.ndim, .shape, .size, .itemsize, .dtype, .nbytes 
print('Attributes of numpy Array')