#user input 
from numpy import*
scan = int(input("Enter Number of Elements: "))
a = zeros(scan, dtype=int)

for i in range(len(a)):
    x = int(input("Enter Element: "))
    a[i] = x
#print(a)

for i in range(len(a)):
    print(a[i])
print()

print("While loop array ")

scan = int(input("Enter Number of Elements :"))
ob = zeros(scan, dtype=int)

le = len(ob)
i = 0
while(i < le):
    y = int(input("Enter Elements: "))
    ob[i] = y
    i+=1

j = 0
while(j < len(ob)):
    print(ob[j])
    j+=1 