#Function -> logspace()
#logspace(start,stop,num=50,endpoint=True,base-10.0,dtype=None,axis=0)

print("Start logspace() ")
from numpy import*
a = logspace(1,3,5)
print(a)

n = len(a)
for i in range(n):
    print(i," = ",a[i])
print()

#Function -> arange()
#arange(start,stop,stepsize,dtype=None)
print("Start arange() ")
from numpy import*
a = arange(1,10,2)
print(a)

n = len(a)
for i in range(n):
    print(i," -> ",a[i])
print()

#zeros() FUnction
#zeros(shape,dtype=float,order='C')
print("Start zero() ")
from numpy import*
a = zeros(5,dtype='int')
print(a)

n = len(a)
i = 0
while i<n:
    print(i," = ",a[i])
    i+=1
print()

#ones() Function
#ones(shape,dtype=float,order='C')
print("Start ones() ")
a = ones(5,order='F')
print(a)

n = len(a)
for i in range(n):
    print(i," = ",a[i])