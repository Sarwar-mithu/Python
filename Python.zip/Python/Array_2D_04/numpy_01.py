#numpy array 1D/2D array
#1D/2D function->(array(), linspace(), logspace(), arange(), zero(), ones())

import numpy
stu_roll = numpy.array([11,12,13,14,15])
print(stu_roll)
print(stu_roll.dtype)

stu_roll[1]=100 #new value in array
print(stu_roll)
print()


stu_name = numpy.array(["Sajada","Taher","mehedi","salman","Aayash"])
print(stu_name)
print(stu_name.dtype)
print()

#from numpy import*
print("from numpy import* ")
from numpy import*
roll = array([99,88,77,66,5])
print(roll)     