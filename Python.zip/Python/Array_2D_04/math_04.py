#mathmetical (Relation/comparing )
from numpy import*
a = array([101,102,103,104,105])
b = array([1,2,3,4,5])
print("Addition,subtraction,multiplication,devision")
c = a + b
print(c)
print()


print("Comparing Arrays using numpy ")
a = array([100,200,300,400,500])
b = array([100,20,30,400,50])

result = a == b           #(a<b), (a>b), etc
n = len(result)

for el in range(n):
    print(el," = ",result[el])

print()

#any(), and all() -> Function
print("any(),  Function ")

print("One condition Satispay : ",any(result))
print()


print("all() Function")
print("All condition satispy : ",all(result))
print()

#where() Function
print("where() Function start")
x = array([100,12,300,4,500])
y = array([1001,20,30,400,50])

result_ob = where(x > y, x, y)
print("if compairing two value : ",result_ob)
print()

#nonzero() Function
print("nonzero() start")
a = array([100,200,0,13,400,0,14])
print("Length : ",len(a))
n = nonzero(a)

print("Print index number : ",n)
print()

#Aliasing Array 
print("Aliasing array start ")
a = array([10,20,3,4])
b = a
print(a)
print(b)
print("a address: ",id(a))
print("b address: ",id(b))
print()

#view() Function
print("view() start ")
x = array([11,22,33,44,55])

y = x.view()
x[1] = 90
x[3] = 77
print(x)
print(y)
print("memory address X : ",id(x))
print("memory address Y : ",id(y))
print()


#copy() method
print("copy() method  start")
z = x.copy()
x[2] = 200
z[0] = 890
print(x)
print(z)
print("memory address X : ",id(x))
print("memory address Y : ",id(z))


