#fromkeys() Method->dict.fromkeys(keys,value)
#get()->dict.get(key,defaultValue)
#items()->dict_name.items()
#keys()->dict_name.keys()
#values()->dict_name.values()
#update()->dict_name.update(iterable)
#pop()->dict_name.pop(key,defaultValue)
#popitem()->dict_name.popitem()
#setdefault()->dict_name.setdefault(key,value)
#Accessing dictionay using for loop

key = (101,102,103)
value = 'mithu'

a = dict.fromkeys(key, value)
print(a)
print()


#get()
stu = {10:'Aayash',11:'Mishu',12:'Mehedi'}
print('Orginal Dict:')
print(stu)
print()


print('Without value',stu.get(12))
x = stu.get(14,'Family')
print('With value:',x)
print()

#items()
a = stu.items()
print('Pair Tuple: ',a)
print()

lst = list(a)  # convert list
print('List:',lst)
print(type(lst))
print()

print(lst[0])
print()

#keys()
all_key = stu.keys()     # only keys access
print('Keys:',all_key)
print()

#values()
all_valu = stu.values()    # only values access
print('values :',all_valu)
print()

#update()
stu.update({13:'update'})    #multiple update in dectionary
print('Update Dectionary : ',stu)
print()

#pop()
removed_valu = stu.pop(13)
print('Pop/Remove : ',stu)
print()
print("Remove value :",removed_valu)
print()

#popitem() , LIFO(last in first out)
stu.popitem()
print('LIFO :',stu)
print()


#setdefault(), method returns the value of the specified key
stu.setdefault(12, 'Python')   #dict thakle return korbe ar na thakleo return korbe
print('Return value: ',stu)
print()

for i in stu:
    print(i,'=',stu[i])
print()

#Getting unser input using for loop

a = {}
scan = int(input('How many Dict :'))

for i in range(scan):
    k = input('Enter key :')
    v = input("Enter value :")

    a.update({k:v})
print(a)

for i in a:
    print(i,'=',a[i])
print()


