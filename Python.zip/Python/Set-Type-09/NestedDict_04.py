#Nested Dictionary
#modifying 
#Delete ->  del a['course']
# add
#new dictionary elements add
#accessing nested for loop
#Creating Nested dict
#passing dictionary
#Return dictionary


a = {'course':'Python','fees':1000, 1:{'course':'java','fees':1500}}
print(a)
print()
print(a['course'])
print(a['fees'])
print(a[1]['course'])
print(a[1]['fees'])
print()


#modifying
a['course']= 'c++'
print('Modify:',a)
print()

# add
a['duration'] = '2 month'
print('New add :',a)
print()

#new dictionary add 
a[2] = {'course':'Reactjs', 'fees':200}
print('new dict :',a)
print()

#Accessing Nested for loop

for i in a:
    if type(a[i]) is dict:
        for j in a[i]:
            print(j,'=',a[i][j])
    
    else:
        print(i,':',a[i])
print()



#Creating Nested Dict
x = { 1:{'name':'mithu', 'add':'Noakhali'},
      2:{'company':'Gaps', 'mobile':'+880'}
    }  
print(x)
print()

x[1]['name'] = 'Sarwar'   #Modify
print('After modify :',x)  #del [1]['name']
print()


x[1]['Blood'] ='B+'    # new elements add
print('New elements :',x)
print()


#Nested for loop
print('Id:')
for i in x:
    print(i)
print()

#keys
for i in x:
    for j in x[i]:
        print(i,j,':',x[i][j])
print()


#passing dictionary
def show(d):
    print(d)
    print(type(d))

    for k in d:
        print(k,':',d[k])
    return d                 #Retuern Function


dc = {101:'Style', 102:'cloth'}
ret_new = show(dc)
print()
show(ret_new)
print()