#list Comprehension-> new_list=[expression for item in iterable_object if_statement]
#new_lst=[expression if_statement else expression for item in iterable_object]
#Nested for loop-> lst=[i*j for j in range(4,7)] for i in range(6,8)]
#set Comprehension
#Dictionary Comprehension


lst1 = [0,1,2,3,4,5,6,7,8,9,]

new_lst1 = [i+1 for i in lst1]   # = [i+1 for i in range(10)]
print(new_lst1)
print()

#with list comprehension (condition)
lst2 = [i for i in range(20) if i%2==0]
print(lst2)
print()

#with list comprehension multiple(condition)
lst2 = [i for i in range(20) if i%2==0 if i%3==0]
print(lst2)
print()


#List comprenhension with ef else statement
lst3 = [i if i%2==0 else 'invalid' for i in range(10)]
print(lst3)
print()



#Nested For loop list Comprehension
las4 = [[i*j for j in range(4,7)] for i in range(6,8)]

print(las4)
print()


#set chmprehension
set1= {i+1 for i in range(10)}
print(set1)
print()


set1= {i for i in range(10) if i%2==0}  #condition
print(set1)
print()

set2 = {i for i in range(10) if i%2==0 if i%3==0}  #condition
print(set2)
print()
#set if else satemente same in list



#set comprehension
set3 = {(i, j) for j in range(4,7) for i in range(6,8)}
print(set3)
print()


#Dictionary Comprehension
dict1 = {i: i*2 for i in range(10)}
print(dict1)
print()

#condition and multiple condition, if else condition
dict2 = {n:(n if n%2==0 else 'invalid') for n in range(10)}
print(dict2)
print()

lst = [(101,'mithu'), (102,'salman') ]
dict3 = {k:v for k,v in lst}
print(dict3)
print()
