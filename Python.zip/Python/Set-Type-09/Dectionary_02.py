#Dectionary
#Modifying
#Inserting / adding new item
#Deletion->del a[102]
#Testing key
#clear()->dict_name.clear()
#copy()->new_dict = dict_name.copy()


a = {101:'Taher',102:'Sajada',103:'Mehedi'}
print(a)
print(a[102])
print()

a[102]='Maa'   #modifying 
print('After Modification: ',a)
print()

#inserting/ adding
a[104]='Python'
print('After insert/add : ',a)
print()

#Deletion
del a[103]
print('Delete : ',a)
print()

#Testing key-> ef exists return True
print('Testing:', 101 in a)      # 101 not in a
print()


