#Set Type
# add() method-> set_name.add(new_element)
#update() method->set_name.update(new_element....)
#Deleting element, remove() or discard() method-> set_n.remove(element), set_n.discard(element)
#copy()-> new_set_name = set_name.copy()
#clear()-> set_name.clear()
#set method
#Passing set to Function
#Getting input from user


a = {10,20,30,'mithu','sarwar',34,10,10}   # a= set()
print(a)
print(type(a))
print(id(a))
print()


# add()
a.add('Aayash')
print('After adding :',a)
print(id(a))
print()

#update()    ,add multiple elements to set 
a.update([99,'update adding'])
print('After update:',a)
print()



#set_n.remove(element), set_n.discard(element)

a.remove('mithu')
print('Removeing method ',a)
print()


a.discard('Deleting')    # program no error find out new elemets
print('Removeing method ',a)
print()


#copy()-> new_set_name = set_name.copy()
new_el = a.copy()
print('copY this file : ',new_el)
print()


#set method
x = {'mithu',10,20,-76,3.1416}
y = {'mithu',11,22,-75,3.1416}

ism = x.intersection(y)         #Inter section method
print('Common Method :',ism)
print()

ism = x.union(y)         #union method
print('union Method :',ism)
print()

ism = x.difference(y)         #difference method
print('X purity :',ism)
print()

ism = x.issubset(y)         #issubset method
print('All condition mandatory :',ism)
print()

ism = x.issuperset(y)         #issuperset method
print('X value mandatory :',ism)
print()


#Passing set to Function and Returning set to function
def show(s):
    print(s)
    print(type(s))
    for i in s:
        print(i)
    return s
st = {10,20,30,'passing'}
new_st = show(st)
show(new_st)
print()

#for loop access set    but for loop with index not access

#Getting input from user
a = set()
n = int(input('Enter Number of Elements: '))

for i in range(n):
    x = input('Enter elements : ',)
    a.add(x)

print(a)
print()

