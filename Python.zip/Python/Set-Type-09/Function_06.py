# id() Function-> id(Object), type(Object), getsizeof() form sys import,
#Type casting->int(),float(),str(),list(),tuple(),set(),dict(**kwarg)
#len(arg),min(iterable),max(iterable),sorted(iterable),
#Membership-> in, not in (10 in a) , a = varibale