#Array Function (one dimensional, two dimensional)

import array
stu_Roll = array.array('i',[101,102,103,104,105])
print("Array : ",stu_Roll)
print(stu_Roll[3])
le = len(stu_Roll)
for j in range(le):

    print(j," = ",stu_Roll[j])
print()

#Another create array

from array import*
serial = array('i',[10,12,13,14,15])
print(serial[0])
print(serial[1])
print(serial[2])
print(serial[3])
print(serial[4])
print()

#while loop array
from array import*
student = array('i',[11,22,33,44,55])
n = len(student)

i = 0
while(i<n):
    print(student[i])
    i+=1
print()


#append() method
from array import*
stu_r = array('i',[99,88,77,66,55])
n = len(stu_r)

i = 0
while(i<n):
    print(stu_r[i])
    i+=1
print("Array after append")
stu_r.append(200)
le = len(stu_r)
i = 0
while(i<le):
    print(stu_r[i])
    i+=1



