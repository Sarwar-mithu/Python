#reverse method()

from array import*
stu_roll = array('i', [101,102,103,104,105])
le = len(stu_roll)

for i in range(le):
    print(i," = ",stu_roll[i])

stu_roll.reverse()

for i in range(len(stu_roll)):
    print("After Reverse : ",stu_roll[i])
print()

#extend() array method
from array import*
stu_id = array('i', [12,13,14,15,16])
arr = array('i',[101,102,103])
le = len(stu_id)

for i in range(le):
    print("=",stu_id[i])
print("Length : ",le)



print("Array after extend")
stu_id.extend(arr)

for j in range(len(stu_id)):
    print(stu_id[j])
value = len(stu_id)
print("Total length : ",value)