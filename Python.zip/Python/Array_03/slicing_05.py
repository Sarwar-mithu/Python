#Slicing on arrays
from array import*
stu_roll = array('i', [101,102,103,104,105,106,107])
print("Orginal array")
n = len(stu_roll)

for i in range(n):
    print(i," = ",stu_roll[i])
print()
print("******Slicing******")

a = stu_roll[1:4]   # stu_roll[-5:-3]
for i in a:
    print(i)
print()

x = stu_roll[0:7:2]
for i in x:
    print(i)