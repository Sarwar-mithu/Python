# Method in array
# pop() method
from array import*
shop = array('i', [])
scan = int(input("How many array :"))

ra = range(scan)
for i in ra:
    shop.append(int(input("Enter Elements : ")))

for j in range(len(shop)):
    print(j," = ", shop[j])
print()

print("Array after pop ")    # laster value delete hoye jabe
shop.pop()
n = len(shop)

for j in range(len(shop)):
    print(shop[j])
print("length : ",len(shop))
print()

#manually pop(metho)
print("Manually pop method ")
shop.pop(1)
le = len(shop)

for j in range(len(shop)):
    print("After pop : ",shop[j])
print()

#remove() method
print("Remove method")
from array import*
ra = array('i', [21,11,31,41,51])
n = len(ra)

for i in range(n):
    print(ra[i])
total = len(ra)
print("Length : ",total)

r = ra.remove(11)
b = len(ra)
for i in range(b):
    print("After Remove : ",ra[i])
print("After total length : ",b)
print()


#Index() method
print("Index method ")
from array import*
stu_roll = array('i', [101,102,101,104,105])
print(stu_roll.index(104))

print(stu_roll.index(101))



