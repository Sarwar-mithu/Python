#user input array for loop
from array import*
ob = array('i', [])
scan = int(input("How many Elements : "))

for i in range(scan):
    ob.append(int(input("Enter Element :")))

for i in range(len(ob)):
    print(i," = ",ob[i])
print()

#Getting input from users using for while loop

from array import*
ar = array('i', [])
scan = int(input("How many While loop array : "))

i = 0
while(i<scan):
    ar.append(int(input("Enter value :")))
    i+=1
    
i = 0 
while(i<len(ar)):
    print(i," = ",ar[i])
    i+=1
print()
print("Array after insert : ")
ar.insert(1,99)
ar.insert(2,89)
n = len(ar)
x = 0
while(x<n):
    print(x," : ",ar[x])
    x+=1